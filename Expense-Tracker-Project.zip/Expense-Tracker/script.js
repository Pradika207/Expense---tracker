
let balance = 0;
let list = document.getElementById("list");

function addExpense() {
  let desc = document.getElementById("desc").value;
  let amount = parseFloat(document.getElementById("amount").value);

  if (!desc || isNaN(amount)) {
    alert("Please enter valid inputs.");
    return;
  }

  balance += amount;
  document.getElementById("balance").innerText = `Balance: ₹${balance}`;

  let li = document.createElement("li");
  li.textContent = `${desc}: ₹${amount}`;
  list.appendChild(li);

  document.getElementById("desc").value = "";
  document.getElementById("amount").value = "";
}
