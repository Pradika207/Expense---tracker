
# Expense Tracker Web App

A simple web app to track expenses using **HTML**, **CSS**, and **JavaScript**.

## Features
- Add and display transactions
- Real-time balance update
- Clean, responsive UI

## How to Run
1. Download or clone this repository.
2. Open `index.html` in any web browser.

## Author
[Your Name](https://github.com/yourusername)
